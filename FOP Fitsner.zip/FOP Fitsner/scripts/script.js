
// Hamburger menu

let hamburgerButton = document.getElementById('menu-button');
let menu = document.getElementById('menu');


function toggleMenu () {
	console.log('toggle')
	menu.classList.toggle('hidden');
	document.body.classList.toggle('no-scroll');
	hamburgerButton.classList.toggle('open');
};

hamburgerButton.addEventListener('click', toggleMenu);


window.addEventListener('mousedown', function(e) {
  if (!(e.target.classList.contains('body')) &&
      !(e.target.classList.contains('hamburger')) &&
      !(e.target.classList.contains('mobile-menu'))) {
  	menu.classList.add('hidden')
	document.body.classList.remove('no-scroll')
	hamburgerButton.classList.remove('open')
  }
})

 
// Widget slider Swiper
new Swiper('.swiper-container', {
   // Вывод стрелок навигации
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  pagination: {
    el: '.swiper-pagination',

  },
    clickable: true,
    autoHeight: false,
    slidesPerView: 3,
    watchOverflow: true,
    loop: true,
    breakpoints:{
    	320:{
    		slidesPerView: 1,
    	},
    	480:{
    		slidesPerView: 2,
    	},
    	992:{
    		slidesPerView: 3,
    	}
    },

    preloadImages: false,

    lazy: {
    	loadOnTransitionStart: false,
    	loadPrevNext:false,
    },
    watchSlidesProgress: true,
    watchSlidesVisibility: true,
  });

// widget accordion

$( function() {
    $( ".accordion" ).accordion({
    	heightStyle: "content",
    	icons: { "header": "ui-icon-plusthick", "activeHeader": "ui-icon-minusthick" },
    	collapsible: true,
    	animate: 500
    });
  } );

// button UP

let up = document.querySelector("div.up");
let down = document.querySelectorAll("down");
window.addEventListener("scroll", function(){
	if(window.pageYOffset > 200){
		up.classList.add("show");
	} else {
		up.classList.remove("show");
	}
});

up.addEventListener("click", function(){
	 window.scrollTo(0,0);
	});

for (i = 0; i<down.length; i++){
	down[i].addEventListener("click", function(e){
            e.preventDefault();
	})
}


let logo = document.querySelector('div.navbar-logo');

logo.addEventListener("click", function(){
	 window.scrollTo(0,0);
	});